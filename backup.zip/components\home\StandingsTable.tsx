'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Equipo } from '@/lib/types';

interface Props {
  equipos: Equipo[];
}

export function StandingsTable({ equipos }: Props) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
      <div className="flex items-center gap-3 mb-3">
        <span className="text-[8px] font-black uppercase tracking-[0.3em] text-zinc-600">Tabla de posiciones</span>
        <div className="flex-1 border-b border-zinc-900" />
      </div>
      <div className="rounded-xl overflow-hidden border border-zinc-900">
        <div className="grid grid-cols-[28px_1fr_44px_44px_44px_44px_44px_44px] bg-zinc-950 border-b border-zinc-800/60 px-3 py-2">
          {['#', 'Equipo', 'Pts', 'PJ', 'G', 'E', 'P', 'DG'].map((h, i) => (
            <span key={h} className={`text-[8px] font-black uppercase tracking-wider ${i === 2 ? 'text-green-600/70' : 'text-zinc-700'} ${i > 1 ? 'text-center' : ''}`}>{h}</span>
          ))}
        </div>
        {equipos.map((eq, i) => (
          <Link key={eq.id} href={`/equipos/${eq.id}`}>
            <motion.div
              initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 + i * 0.04 }}
              className={`grid grid-cols-[28px_1fr_44px_44px_44px_44px_44px_44px] px-3 py-3 border-b border-zinc-900/60 last:border-0 transition-colors hover:bg-zinc-900/50 group ${i === 0 ? 'bg-green-500/5' : ''}`}
            >
              <span className={`text-[9px] font-black font-mono self-center ${i === 0 ? 'text-green-500' : 'text-zinc-700'}`}>{i + 1}</span>
              <div className="flex items-center gap-2 min-w-0">
                <div className="relative w-5 h-5 shrink-0">
                  <Image src={`/escudos/${eq.id}.png`} alt="" fill className="object-contain" />
                </div>
                <span className={`text-[11px] font-black uppercase tracking-tight truncate ${i === 0 ? 'text-white' : 'text-zinc-400 group-hover:text-white transition-colors'}`}>{eq.nombre}</span>
              </div>
              <span className="text-center text-sm font-black text-green-400 tabular-nums self-center">{eq.puntos || 0}</span>
              <span className="text-center text-[11px] text-zinc-600 tabular-nums self-center">{eq.pj || 0}</span>
              <span className="text-center text-[11px] text-zinc-600 tabular-nums self-center">{eq.pg || 0}</span>
              <span className="text-center text-[11px] text-zinc-600 tabular-nums self-center">{eq.pe || 0}</span>
              <span className="text-center text-[11px] text-zinc-600 tabular-nums self-center">{eq.pp || 0}</span>
              <span className={`text-center text-[11px] font-mono tabular-nums self-center ${(eq.df || 0) >= 0 ? 'text-zinc-500' : 'text-red-700'}`}>
                {(eq.df || 0) > 0 ? `+${eq.df}` : eq.df || 0}
              </span>
            </motion.div>
          </Link>
        ))}
      </div>
    </motion.div>
  );
}
