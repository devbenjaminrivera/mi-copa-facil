'use client';

import Image from 'next/image';
import { motion, Variants } from 'framer-motion';
import { Jugador } from '@/lib/types';

interface Props {
  goleadores: Jugador[];
  isPlayoffsMode: boolean;
}

const PODIO_STYLES = [
  { glow: 'drop-shadow-[0_0_18px_rgba(234,179,8,0.7)]',  badge: 'bg-yellow-500 text-black', size: 'w-24 h-24' },
  { glow: 'drop-shadow-[0_0_12px_rgba(161,161,170,0.5)]', badge: 'bg-zinc-400 text-black',   size: 'w-16 h-16' },
  { glow: 'drop-shadow-[0_0_12px_rgba(154,52,18,0.5)]',   badge: 'bg-orange-800 text-white', size: 'w-16 h-16' },
];

export function TopScorers({ goleadores, isPlayoffsMode }: Props) {
  const itemVariants: Variants = {
    hidden: { y: 16, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.4, ease: 'easeOut' } }
  };

  const podioOrder = [1, 0, 2];

  return (
    <motion.section variants={itemVariants} initial="hidden" animate="visible" className="lg:col-span-4">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-1 h-5 bg-green-500 rounded-full shrink-0" />
        <span className="font-impact tracking-[-0.01em] text-xl font-black italic uppercase text-white leading-none shrink-0">
          {isPlayoffsMode ? 'GOLEADORES' : 'Top goleadores'}
        </span>
        <div className="flex-1 border-b border-zinc-900" />
      </div>

      {goleadores.length > 0 && (
        <div className="flex items-end justify-center gap-3 mb-4 px-2 pt-2">
          {podioOrder.map((pos) => {
            const g = goleadores[pos];
            if (!g) return <div key={pos} className="flex-1" />;
            const style = PODIO_STYLES[pos];
            
            // Handle relations that could be array or single object
            const equiposArray = Array.isArray(g.equipos) ? g.equipos : (g.equipos ? [g.equipos] : []);
            const equipoId = equiposArray[0]?.id;
            
            const partes = (g.nombre || '').trim().split(' ');
            const nombreCorto = partes.length > 1 ? `${partes[0]} ${partes[1].charAt(0)}.` : partes[0];
            return (
              <motion.div variants={itemVariants} key={pos} className={`flex-1 flex flex-col items-center gap-2 ${pos === 0 ? '' : 'opacity-80'}`}>
                <div className={`relative ${style.size} ${style.glow} transition-all duration-500`}>
                  {equipoId && <Image src={`/escudos/${equipoId}.png`} alt="" fill className="object-contain" />}
                  <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black ${style.badge} border-2 border-black`}>{pos + 1}</div>
                </div>
                <div className="text-center">
                  <p className="text-[9px] font-black uppercase text-zinc-400 truncate w-full px-1" title={g.nombre}>{nombreCorto}</p>
                  <p className={`font-black italic text-green-400 leading-none ${pos === 0 ? 'text-2xl' : 'text-xl'}`}>{g.goles}</p>
                  <p className="text-[7px] text-zinc-700 uppercase font-black tracking-wider">goles</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {goleadores.slice(3).length > 0 && (
        <div className="border border-zinc-800/60 rounded-2xl overflow-hidden">
          {goleadores.slice(3).map((g, i) => {
            const equiposArray = Array.isArray(g.equipos) ? g.equipos : (g.equipos ? [g.equipos] : []);
            const equipoId = equiposArray[0]?.id;
            const equipoNombre = equiposArray[0]?.nombre;
            return (
              <motion.div variants={itemVariants} key={i}
                className="flex items-center justify-between px-4 py-3.5 border-b border-zinc-800/40 last:border-0 hover:bg-zinc-900/40 transition-colors group">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-[9px] font-mono text-zinc-700 w-4 shrink-0">{i + 4}</span>
                  {equipoId && <div className="relative w-6 h-6 shrink-0"><Image src={`/escudos/${equipoId}.png`} alt="" fill className="object-contain" /></div>}
                  <div className="min-w-0">
                    <p className="font-black text-xs uppercase truncate text-zinc-300 group-hover:text-white transition-colors">{g.nombre}</p>
                    <p className="text-[8px] text-zinc-700 uppercase tracking-widest truncate">{equipoNombre}</p>
                  </div>
                </div>
                <span className="text-green-400 font-black text-base italic ml-3 shrink-0">{g.goles}</span>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.section>
  );
}
