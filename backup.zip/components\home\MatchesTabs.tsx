'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { Partido } from '@/lib/types';

interface Props {
  partidos: Partido[];
  proximos: Partido[];
}

export function MatchesTabs({ partidos, proximos }: Props) {
  const [tab, setTab] = useState<'resultados' | 'proximos'>('resultados');

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
      <div className="flex items-center gap-0 mb-4 border border-zinc-800 rounded-lg overflow-hidden w-fit">
        {(['resultados', 'proximos'] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-[9px] font-black uppercase tracking-widest transition-all ${tab === t ? 'bg-zinc-800 text-white' : 'text-zinc-600 hover:text-zinc-400'}`}>
            {t === 'resultados' ? 'Últimos resultados' : 'Próximos'}
          </button>
        ))}
      </div>
      <AnimatePresence mode="wait">
        {tab === 'resultados' ? (
          <motion.div key="resultados" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }} className="space-y-2">
            {partidos.map((p) => {
              const lW = (p.goles_local ?? 0) > (p.goles_visita ?? 0);
              const vW = (p.goles_visita ?? 0) > (p.goles_local ?? 0);
              return (
                <Link key={p.id} href={`/resultados#partido-${p.id}`}>
                  <div className="grid grid-cols-[1fr_auto_1fr] gap-3 items-center px-4 py-3.5 rounded-xl border border-zinc-900 hover:border-zinc-700 hover:bg-zinc-900/30 transition-all group">
                    <div className="flex items-center gap-2 justify-end min-w-0">
                      <span className={`text-[11px] font-black uppercase tracking-tight truncate text-right ${lW ? 'text-white' : 'text-zinc-600'}`}>{p.equipo_local?.nombre}</span>
                      <div className="relative w-6 h-6 shrink-0"><Image src={`/escudos/${p.equipo_local?.id}.png`} alt="" fill className="object-contain" /></div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`font-impact text-xl leading-none tabular-nums ${lW ? 'text-white' : 'text-zinc-700'}`}>{p.goles_local}</span>
                      <span className="text-zinc-800 text-xs font-black">–</span>
                      <span className={`font-impact text-xl leading-none tabular-nums ${vW ? 'text-white' : 'text-zinc-700'}`}>{p.goles_visita}</span>
                    </div>
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="relative w-6 h-6 shrink-0"><Image src={`/escudos/${p.equipo_visita?.id}.png`} alt="" fill className="object-contain" /></div>
                      <span className={`text-[11px] font-black uppercase tracking-tight truncate ${vW ? 'text-white' : 'text-zinc-600'}`}>{p.equipo_visita?.nombre}</span>
                    </div>
                  </div>
                </Link>
              );
            })}
            <div className="text-right pt-1">
              <Link href="/resultados" className="text-[8px] font-black uppercase tracking-widest text-zinc-700 hover:text-green-500 transition-colors">Ver historial completo →</Link>
            </div>
          </motion.div>
        ) : (
          <motion.div key="proximos" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }} className="space-y-2">
            {proximos.length === 0 ? (
              <p className="text-center text-zinc-800 text-[9px] font-black uppercase tracking-widest py-10">No hay partidos programados</p>
            ) : proximos.map((p) => (
              <div key={p.id} className="grid grid-cols-[1fr_auto_1fr] gap-3 items-center px-4 py-3.5 rounded-xl border border-zinc-900">
                <div className="flex items-center gap-2 justify-end min-w-0">
                  <span className="text-[11px] font-black uppercase tracking-tight truncate text-right text-zinc-400">{p.equipo_local?.nombre}</span>
                  <div className="relative w-6 h-6 shrink-0"><Image src={`/escudos/${p.equipo_local?.id}.png`} alt="" fill className="object-contain" /></div>
                </div>
                <div className="flex flex-col items-center gap-0.5 shrink-0">
                  <span className="text-[8px] font-black text-zinc-700 uppercase tracking-wider">{p.fecha ? new Date(p.fecha).toLocaleDateString('es-CL', { day: '2-digit', month: 'short' }) : 'TBD'}</span>
                  <span className="text-[9px] font-black text-green-600 uppercase tracking-widest border border-zinc-800 px-2 py-0.5 rounded">J{p.jornada}</span>
                </div>
                <div className="flex items-center gap-2 min-w-0">
                  <div className="relative w-6 h-6 shrink-0"><Image src={`/escudos/${p.equipo_visita?.id}.png`} alt="" fill className="object-contain" /></div>
                  <span className="text-[11px] font-black uppercase tracking-tight truncate text-zinc-400">{p.equipo_visita?.nombre}</span>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
