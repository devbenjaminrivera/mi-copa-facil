import { supabase } from '@/lib/supabase';
import { DashboardData, Equipo, Partido, Jugador, ConfiguracionTorneo } from '@/lib/types';
import { LeaderboardCard } from '@/components/home/LeaderboardCard';
import { StandingsTable } from '@/components/home/StandingsTable';
import { MatchesTabs } from '@/components/home/MatchesTabs';
import { TopScorers } from '@/components/home/TopScorers';
import { BracketPlayoffs } from '@/components/home/BracketPlayoffs';

// Evita que Next.js intente cachear la página si los datos cambian mucho
export const revalidate = 60; // Revalida cada 60 segundos

export default async function Home() {
  const ahora = new Date().toISOString();

  // Fetching de datos en el servidor
  const [resEq, resPart, resProx, resGol, resPlayoffs, resConfig] = await Promise.all([
    supabase.from('equipos').select('*').order('puntos', { ascending: false }).order('df', { ascending: false }).order('gf', { ascending: false }),
    supabase.from('partidos').select(`id, goles_local, goles_visita, fecha, equipo_local:equipos!equipo_local(id, nombre), equipo_visita:equipos!equipo_visita(id, nombre), sanciones(tipo, id_equipo)`)
      .eq('estado', 'jugado').eq('fase', 'regular').order('created_at', { ascending: false }).limit(6),
    supabase.from('partidos').select(`id, fecha, jornada, equipo_local:equipos!equipo_local(id, nombre), equipo_visita:equipos!equipo_visita(id, nombre)`)
      .eq('estado', 'programado').eq('fase', 'regular').gt('fecha', ahora).order('jornada', { ascending: true }).order('fecha', { ascending: true }),
    supabase.from('jugadores').select(`nombre, goles, equipos:id_equipo(id, nombre)`).gt('goles', 0).order('goles', { ascending: false }).limit(5),
    supabase.from('partidos').select(`id, estado, fase, llave, goles_local, goles_visita, penales_local, penales_visita, fecha, equipo_local:equipos!equipo_local(id, nombre), equipo_visita:equipos!equipo_visita(id, nombre)`)
      .neq('fase', 'regular'),
    supabase.from('configuracion_torneo').select('nombre_edicion').single()
  ]);

  const data: DashboardData & { configuracion: { nombre_edicion: string } } = {
    equipos: (resEq.data as unknown as Equipo[]) || [],
    partidos: (resPart.data as unknown as Partido[]) || [],
    proximos: (resProx.data as unknown as Partido[]) || [],
    goleadores: (resGol.data as unknown as Jugador[]) || [],
    playoffs: (resPlayoffs.data as unknown as Partido[]) || [],
    configuracion: (resConfig.data as { nombre_edicion: string }) || { nombre_edicion: 'Copa CEVI' }
  };

  const isPlayoffsMode = data.playoffs.length > 0;
  const lider = data.equipos[0];
  const nombreEdicion = data.configuracion.nombre_edicion;

  return (
    <main className="bg-[#0a0a0a] text-white min-h-screen font-narrow">
      <div className="max-w-6xl mx-auto px-4 md:px-8 pt-6 pb-24">

        {/* MASTHEAD */}
        <div className="mb-8 md:mb-12 border-b border-zinc-800 pb-6 animate-in fade-in duration-700">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-green-500 text-[9px] font-black uppercase tracking-[0.4em] mb-2">
                {nombreEdicion}
              </p>
              <h1 className="font-impact text-[clamp(3rem,10vw,6rem)] leading-[0.9] tracking-[-0.02em] uppercase text-white font-black italic">
                COPA<br/><span className="text-green-500">CEVI</span>
              </h1>
            </div>
          </div>
        </div>

        {/* BRACKET PLAYOFFS */}
        <BracketPlayoffs partidos={data.playoffs} />

        {/* LAYOUT PRINCIPAL */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6 items-start">

          {/* COLUMNA IZQUIERDA */}
          <div className="space-y-6 order-2 lg:order-1">
            <LeaderboardCard lider={lider} isPlayoffsMode={isPlayoffsMode} />
            <StandingsTable equipos={data.equipos} />
            <MatchesTabs partidos={data.partidos} proximos={data.proximos} />
          </div>

          {/* COLUMNA DERECHA */}
          <div className="space-y-5 order-1 lg:order-2">
            <TopScorers goleadores={data.goleadores} isPlayoffsMode={isPlayoffsMode} />
          </div>
        </div>

        {/* FOOTER */}
        <footer className="mt-20 pt-6 border-t border-zinc-900 flex items-center justify-between">
          <p className="text-zinc-800 text-[8px] uppercase tracking-[0.4em] font-black">{nombreEdicion}</p>
          <p className="text-zinc-800 text-[8px] uppercase tracking-[0.3em] font-black">Benjamín Rivera Araneda</p>
        </footer>

      </div>
    </main>
  );
}