'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { ConfiguracionTorneo, Equipo, Jugador, Partido } from '@/lib/types';

export default function AjustesTorneo() {
  const [config, setConfig] = useState<ConfiguracionTorneo>({
    id: 1,
    nombre_edicion: 'Copa Fácil',
    puntos_victoria: 3,
    equipos_playoffs: 4
  });
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);

  // Formulario de cierre manual
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [campeon, setCampeon] = useState('');
  const [subcampeon, setSubcampeon] = useState('');
  const [goleador, setGoleador] = useState('');
  const [golesGoleador, setGolesGoleador] = useState<number | ''>('');
  const [mvp, setMvp] = useState('');

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    // Cargar config
    const { data: conf } = await supabase.from('configuracion_torneo').select('*').single();
    if (conf) setConfig(conf);

    // Cargar sugerencias para el cierre
    const { data: eq } = await supabase.from('equipos').select('*');
    const { data: jug } = await supabase.from('jugadores').select('*').order('goles', { ascending: false }).limit(1);
    const { data: final } = await supabase.from('partidos')
      .select('*, equipo_local:equipos!equipo_local(nombre), equipo_visita:equipos!equipo_visita(nombre), mvp:jugadores!id_mvp(nombre)')
      .eq('llave', 'oro')
      .single();

    if (jug && jug.length > 0) {
      setGoleador(jug[0].nombre);
      setGolesGoleador(jug[0].goles);
    }

    if (final && final.estado === 'jugado') {
      const gL = final.goles_local || 0;
      const gV = final.goles_visita || 0;
      const pL = final.penales_local || 0;
      const pV = final.penales_visita || 0;
      const localWin = gL > gV || (gL === gV && pL > pV);
      
      const c = localWin ? final.equipo_local?.nombre : final.equipo_visita?.nombre;
      const sc = localWin ? final.equipo_visita?.nombre : final.equipo_local?.nombre;
      
      if (c) setCampeon(c);
      if (sc) setSubcampeon(sc);
      if (final.mvp) setMvp(final.mvp.nombre);
    } else if (eq && eq.length > 0) {
      // Fallback a los punteros de la tabla si no hay final
      const ordenados = [...eq].sort((a, b) => {
        if (b.puntos !== a.puntos) return b.puntos - a.puntos;
        if (b.df !== a.df) return b.df - a.df;
        return b.gf - a.gf;
      });
      setCampeon(ordenados[0].nombre);
      if (ordenados[1]) setSubcampeon(ordenados[1].nombre);
    }

    setCargando(false);
  };

  const guardarConfiguracion = async () => {
    setGuardando(true);
    const { error } = await supabase.from('configuracion_torneo').upsert(config);
    setGuardando(false);
    if (error) alert('Error guardando configuración: ' + error.message);
    else alert('Configuración guardada correctamente.');
  };

  const generarPlayoffs = async () => {
    if (!confirm('¿Seguro que deseas generar los playoffs usando el Top 4 actual de la tabla? Esto sobrescribirá semifinales pendientes.')) return;
    
    // Obtener top 4
    const { data: equipos, error: errEq } = await supabase
      .from('equipos')
      .select('*')
      .order('puntos', { ascending: false })
      .order('df', { ascending: false })
      .order('gf', { ascending: false })
      .limit(4);

    if (errEq || !equipos || equipos.length < 4) {
      return alert('No hay suficientes equipos (se necesitan 4) para generar playoffs.');
    }

    // Borrar llaves anteriores no jugadas (opcional, por si la regeneran)
    await supabase.from('partidos').delete().in('llave', ['semi_1', 'semi_2']).eq('estado', 'programado');

    const nuevosPartidos = [
      {
        fase: 'playoffs',
        llave: 'semi_1',
        equipo_local: equipos[0].id,
        equipo_visita: equipos[3].id,
        estado: 'programado',
        jornada: 99
      },
      {
        fase: 'playoffs',
        llave: 'semi_2',
        equipo_local: equipos[1].id,
        equipo_visita: equipos[2].id,
        estado: 'programado',
        jornada: 99
      }
    ];

    const { error } = await supabase.from('partidos').insert(nuevosPartidos);
    if (error) {
      alert('Error al generar playoffs: ' + error.message);
    } else {
      alert('Playoffs generados correctamente! 1º vs 4º y 2º vs 3º');
    }
  };

  const cerrarCampeonato = async () => {
    if (!campeon || !subcampeon) {
      return alert('Debes especificar al campeón y subcampeón.');
    }

    const confrm = confirm(`⚠️ ADVERTENCIA CRÍTICA ⚠️\n\nEstás a punto de finalizar la edición "${config.nombre_edicion}".\n\nEsto va a ELIMINAR TODOS los partidos, goles y actas actuales de la base de datos de manera irreversible, y reiniciará todos los puntos a CERO.\n\nSolo quedará el registro del campeón en el Historial.\n\n¿Estás absolutamente seguro de que el torneo ha finalizado y quieres empezar uno nuevo?`);
    
    if (!confrm) return;

    setGuardando(true);
    
    const { error } = await supabase.rpc('cerrar_campeonato', {
      p_edicion: config.nombre_edicion,
      p_campeon: campeon,
      p_subcampeon: subcampeon,
      p_goleador: goleador || null,
      p_goles_goleador: typeof golesGoleador === 'number' ? golesGoleador : 0,
      p_mvp: mvp || null
    });

    setGuardando(false);
    setShowCloseModal(false);

    if (error) {
      alert('Hubo un error al cerrar el campeonato: ' + error.message);
    } else {
      alert('¡Campeonato cerrado con éxito! El historial ha sido guardado y el sistema está limpio para una nueva edición.');
      window.location.reload();
    }
  };

  const inputBase = 'w-full bg-zinc-900/40 border border-zinc-800 hover:border-zinc-700 focus:border-green-500 p-4 rounded-2xl outline-none transition-all font-bold text-sm';

  if (cargando) return <div className="p-10 text-white">Cargando ajustes...</div>;

  return (
    <div className="p-4 md:p-10 text-white font-sans pb-20">
      <div className="max-w-3xl mx-auto space-y-8">

        {/* HEADER */}
        <header className="pt-6">
          <p className="text-green-500 font-mono text-[10px] uppercase tracking-[0.3em] mb-3">
            Admin / Ajustes
          </p>
          <h1 className="text-4xl md:text-5xl font-black tracking-tighter uppercase italic leading-none">
            Configuración Global
          </h1>
        </header>

        {/* 1. CONFIGURACIÓN DEL TORNEO */}
        <section className="bg-zinc-900/30 border border-zinc-800/60 rounded-3xl p-6 md:p-8">
          <h2 className="text-lg font-black uppercase tracking-tight mb-6 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            Datos de la Edición
          </h2>
          
          <div className="space-y-5">
            <div>
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.25em] block mb-2">
                Nombre de la Edición Actual
              </label>
              <input 
                type="text" 
                value={config.nombre_edicion} 
                onChange={e => setConfig({...config, nombre_edicion: e.target.value})}
                className={inputBase}
                placeholder="Ej. Copa Verano 2026"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.25em] block mb-2">
                  Puntos por Victoria
                </label>
                <input 
                  type="number" 
                  value={config.puntos_victoria} 
                  onChange={e => setConfig({...config, puntos_victoria: parseInt(e.target.value) || 0})}
                  className={inputBase}
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.25em] block mb-2">
                  Equipos en Playoffs
                </label>
                <input 
                  type="number" 
                  value={config.equipos_playoffs} 
                  onChange={e => setConfig({...config, equipos_playoffs: parseInt(e.target.value) || 0})}
                  className={inputBase}
                  disabled
                />
              </div>
            </div>

            <button 
              onClick={guardarConfiguracion}
              disabled={guardando}
              className="mt-4 bg-white text-black font-black uppercase text-xs tracking-widest px-6 py-3 rounded-xl hover:bg-green-400 transition-colors"
            >
              Guardar Cambios
            </button>
          </div>
        </section>

        {/* 2. GENERADOR DE PLAYOFFS */}
        <section className="bg-zinc-900/30 border border-zinc-800/60 rounded-3xl p-6 md:p-8">
          <h2 className="text-lg font-black uppercase tracking-tight mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-yellow-500" />
            Automatización de Playoffs
          </h2>
          <p className="text-zinc-400 text-sm mb-6 leading-relaxed">
            Cuando haya terminado la fase regular, presiona este botón. El sistema leerá la tabla de posiciones y agendará las Semifinales (1º vs 4º y 2º vs 3º) automáticamente.
          </p>
          <button 
            onClick={generarPlayoffs}
            className="w-full border border-yellow-500/30 text-yellow-500 font-black uppercase text-xs tracking-widest px-6 py-4 rounded-xl hover:bg-yellow-500/10 transition-colors"
          >
            Generar Llaves Semifinales
          </button>
        </section>

        {/* 3. PELIGRO: CERRAR CAMPEONATO */}
        <section className="bg-red-950/20 border border-red-900/50 rounded-3xl p-6 md:p-8">
          <h2 className="text-lg font-black uppercase tracking-tight text-red-500 mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
            Zona de Peligro: Cerrar Edición
          </h2>
          <p className="text-zinc-400 text-sm mb-6 leading-relaxed">
            Esta acción finalizará el campeonato. Guardará el palmarés en el historial y <strong className="text-red-400">borrará todos los partidos jugados y goles</strong>, reiniciando los puntos a 0 para empezar un nuevo torneo.
          </p>
          
          <button 
            onClick={() => setShowCloseModal(true)}
            className="w-full bg-red-600/20 border border-red-600/50 text-red-500 font-black uppercase text-xs tracking-widest px-6 py-4 rounded-xl hover:bg-red-600 hover:text-white transition-all"
          >
            Finalizar Campeonato y Reiniciar
          </button>
        </section>

      </div>

      {/* MODAL CERRAR CAMPEONATO */}
      {showCloseModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 max-w-md w-full animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-2xl font-black italic uppercase tracking-tight text-white mb-1">
              Registro del Palmarés
            </h3>
            <p className="text-xs text-zinc-500 mb-6">Revisa y confirma los ganadores antes de que se borren los datos de la fase regular.</p>

            <div className="space-y-4 mb-8">
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-1">Campeón</label>
                <input type="text" className={`${inputBase} p-3 text-white border-yellow-500/30`} value={campeon} onChange={e => setCampeon(e.target.value)} />
              </div>
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-1">Subcampeón</label>
                <input type="text" className={`${inputBase} p-3`} value={subcampeon} onChange={e => setSubcampeon(e.target.value)} />
              </div>
              <div className="grid grid-cols-[1fr_100px] gap-2">
                <div>
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-1">Goleador</label>
                  <input type="text" className={`${inputBase} p-3`} value={goleador} onChange={e => setGoleador(e.target.value)} />
                </div>
                <div>
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-1">Goles</label>
                  <input type="number" className={`${inputBase} p-3 text-center`} value={golesGoleador} onChange={e => setGolesGoleador(parseInt(e.target.value) || '')} />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-1">MVP de la Final (Opcional)</label>
                <input type="text" className={`${inputBase} p-3`} value={mvp} onChange={e => setMvp(e.target.value)} />
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setShowCloseModal(false)}
                className="flex-1 py-3 text-xs font-black uppercase tracking-widest text-zinc-500 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={cerrarCampeonato}
                disabled={guardando}
                className="flex-1 bg-red-600 text-white py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-red-500 transition-colors"
              >
                {guardando ? 'Borrando...' : 'Confirmar Fin'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
