import { supabase } from '@/lib/supabase';
import { Partido } from '@/lib/types';
import { ResultadosList } from './ResultadosList';

export const revalidate = 60; // Revalida cada 60 segundos

export default async function ResultadosCompletos() {
  const { data } = await supabase
    .from('partidos')
    .select(`
      id, goles_local, goles_visita, jornada, fecha,
      mvp:jugadores!id_mvp(nombre),
      equipo_local:equipos!equipo_local(id, nombre),
      equipo_visita:equipos!equipo_visita(id, nombre),
      sanciones(tipo, id_equipo, jugador:jugadores(nombre)),
      goles(id_equipo, jugador:jugadores(nombre))
    `)
    .eq('estado', 'jugado')
    .order('jornada', { ascending: false })
    .order('fecha', { ascending: false });

  const partidos = (data as unknown as Partido[]) || [];

  // AGRUPAR POR JORNADAS para calcular número de jornadas
  const jornadas = partidos.reduce((acc: any, p: Partido) => {
    const j = String(p.jornada || 1);
    if (!acc[j]) acc[j] = [];
    acc[j].push(p);
    return acc;
  }, {});

  const jornadasOrdenadas = Object.keys(jornadas).sort((a, b) => Number(b) - Number(a));
  const totalGoles = partidos.reduce((a, p) => a + (p.goles_local || 0) + (p.goles_visita || 0), 0);

  return (
    <main className="bg-[#0a0a0a] text-white min-h-screen pb-24 font-narrow">
      {/* ── HEADER EDITORIAL ─────────────────────────────────────── */}
      <div className="border-b border-zinc-900 pt-14 mb-10">
        <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 animate-in fade-in duration-500">
          <div>
            <p className="text-green-500 text-[9px] font-black uppercase tracking-[0.4em] mb-3">
              Copa CEVI 2026 · Actas oficiales
            </p>
            <div className="flex items-end justify-between">
              <h1 className="font-impact text-[clamp(2.5rem,8vw,5rem)] leading-[0.9] tracking-[-0.02em] uppercase font-black italic text-white">
                RESULTADOS
              </h1>
              {/* STATS RÁPIDAS */}
              <div className="hidden md:flex items-end gap-6 pb-1">
                <div className="text-right">
                  <p className="font-impact text-3xl font-black text-zinc-700 leading-none">{partidos.length}</p>
                  <p className="text-[7px] font-black uppercase tracking-widest text-zinc-800 mt-0.5">partidos</p>
                </div>
                <div className="text-right">
                  <p className="font-impact text-3xl font-black text-green-600 leading-none">{totalGoles}</p>
                  <p className="text-[7px] font-black uppercase tracking-widest text-zinc-800 mt-0.5">goles</p>
                </div>
                <div className="text-right">
                  <p className="font-impact text-3xl font-black text-zinc-700 leading-none">{jornadasOrdenadas.length}</p>
                  <p className="text-[7px] font-black uppercase tracking-widest text-zinc-800 mt-0.5">jornadas</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── CONTENIDO (TODAS LAS JORNADAS) ────────────────────────── */}
      <ResultadosList partidos={partidos} />
    </main>
  );
}