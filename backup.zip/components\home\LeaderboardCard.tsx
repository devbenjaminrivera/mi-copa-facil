'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Equipo } from '@/lib/types';

interface Props {
  lider: Equipo;
  isPlayoffsMode: boolean;
}

export function LeaderboardCard({ lider, isPlayoffsMode }: Props) {
  if (!lider || isPlayoffsMode) return null;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
      <Link href={`/equipos/${lider.id}`}>
        <div className="relative overflow-hidden rounded-xl cursor-pointer group" style={{ background: 'linear-gradient(135deg, #111 0%, #0d0d0d 100%)' }}>
          <div className="absolute inset-0 opacity-5">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="absolute border-t border-white" style={{ top: `${i * 14}%`, left: 0, right: 0, transform: `rotate(${i % 2 === 0 ? '-1deg' : '1deg'})` }} />
            ))}
          </div>
          <div className="relative p-6 md:p-8">
            <div className="flex items-start justify-between mb-6">
              <div>
                <span className="inline-block bg-green-500 text-black text-[8px] font-black uppercase tracking-[0.3em] px-2 py-0.5 mb-3">
                  Líder del torneo
                </span>
                <h2 className="font-impact text-[clamp(1.8rem,6vw,3.5rem)] leading-[0.9] tracking-[-0.01em] uppercase text-white group-hover:text-green-400 transition-colors font-black italic">
                  {lider.nombre}
                </h2>
              </div>
              <div className="relative w-20 h-20 md:w-28 md:h-28 shrink-0 ml-4" style={{ filter: 'drop-shadow(0 0 24px rgba(74,222,128,0.4))' }}>
                <Image src={`/escudos/${lider.id}.png`} alt={lider.nombre} fill className="object-contain" />
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2 md:gap-4">
              {[
                { label: 'Puntos', value: lider.puntos, accent: true },
                { label: 'Jugados', value: lider.pj },
                { label: 'Ganados', value: lider.pg },
                { label: 'Dif. goles', value: lider.df > 0 ? `+${lider.df}` : lider.df },
              ].map(({ label, value, accent }) => (
                <div key={label} className="border-t-2 border-zinc-800 pt-3 group-hover:[&:first-child]:border-green-500 transition-colors">
                  <p className={`font-impact text-3xl md:text-4xl font-black leading-none ${accent ? 'text-green-400' : 'text-white'}`}>
                    {value ?? 0}
                  </p>
                  <p className="text-[8px] font-black uppercase tracking-widest text-zinc-600 mt-1">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
